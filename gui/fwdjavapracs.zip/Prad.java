class Prad
{
public static void main(String z[])
{
int a,b,c;
a=Integer.parseInt(z[0]);
b=Integer.parseInt(z[1]);
c=a+b;
System.out.println("Addition = "+c);
}
}