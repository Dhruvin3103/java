import javax.swing.*;
class XYZ {
    public static void main(String[] args) {        
        JFrame jf=new JFrame();
        jf.setVisible(true);
        jf.setSize(500, 500);
        jf.setTitle("My First Frame");
        jf.setLocation(300, 100);
       jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
}